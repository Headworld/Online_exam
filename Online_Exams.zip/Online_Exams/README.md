# Online_Examination_PHP
It is a PHP based Online Examination Project. In this Student Ranking System is also introduced Student can see their ranks. A complete admin panel, Admin can add Quiz, Delete Quiz, Read Feedback by the user.
